package CS360.ProjectTwoInventoryApp;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {
    // --- Database Info ---
    private static final String DATABASE_NAME = "InventoryApp.db";
    private static final int DATABASE_VERSION = 2;

    // --- USERS table ---
    public static final String TABLE_USERS = "users";
    private static final String COL_USER_ID = "id";
    private static final String COL_USERNAME = "username";
    private static final String COL_PASSWORD = "password";

    // --- ITEMS table ---
    public static final String TABLE_ITEMS = "items";
    private static final String COL_ITEM_ID = "id";
    private static final String COL_ITEM_NAME = "name";
    private static final String COL_ITEM_QUANTITY = "quantity";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create USERS table
        String createUsers = "CREATE TABLE " + TABLE_USERS + " (" +
                COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_USERNAME + " TEXT UNIQUE, " +
                COL_PASSWORD + " TEXT" +
                ")";
        db.execSQL(createUsers);

        // Create ITEMS table
        String createItems = "CREATE TABLE " + TABLE_ITEMS + " (" +
                COL_ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_ITEM_NAME + " TEXT, " +
                COL_ITEM_QUANTITY + " INTEGER DEFAULT 0" +
                ")";
        db.execSQL(createItems);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldV, int newV) {
        if (oldV < 2) {
            String alterItems = "ALTER TABLE " + TABLE_ITEMS +
                    " ADD COLUMN " + COL_ITEM_QUANTITY + " INTEGER DEFAULT 0";
            db.execSQL(alterItems);
        }
    }


    //  --- USER methods ---

    /** Insert a new user. Returns true if successful. */
    public boolean addUser(String username, String password) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_USERNAME, username);
        cv.put(COL_PASSWORD, password);
        long res = db.insert(TABLE_USERS, null, cv);
        db.close();
        return res != -1;
    }

    /** Check credentials. Returns true if username/password match. */
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(
                TABLE_USERS,
                new String[]{COL_USER_ID},
                COL_USERNAME + "=? AND " + COL_PASSWORD + "=?",
                new String[]{username, password},
                null, null, null
        );
        boolean exists = (c.getCount() > 0);
        c.close();
        db.close();
        return exists;
    }

    //  --- ITEM methods ---

    /** Add a new item with name and quantity. Returns the new row ID. */
    public long addItem(String name, int quantity) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_ITEM_NAME, name);
        cv.put(COL_ITEM_QUANTITY, quantity);
        long id = db.insert(TABLE_ITEMS, null, cv);
        db.close();
        return id;
    }

    /** Get all items ordered by ID ascending. */
    public List<Item> getAllItemsOrderedById() {
        List<Item> items = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(
                TABLE_ITEMS,
                new String[]{COL_ITEM_ID, COL_ITEM_NAME, COL_ITEM_QUANTITY},
                null, null, null, null,
                COL_ITEM_ID + " ASC"
        );

        while (c.moveToNext()) {
            long id = c.getLong(c.getColumnIndexOrThrow(COL_ITEM_ID));
            String name = c.getString(c.getColumnIndexOrThrow(COL_ITEM_NAME));
            int qty = c.getInt(c.getColumnIndexOrThrow(COL_ITEM_QUANTITY));
            items.add(new Item(id, name, qty));
        }

        c.close();
        db.close();
        return items;
    }

    /** Update an existing item by ID. Returns number of rows affected. */
    public int updateItem(long id, String newName, int newQuantity) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_ITEM_NAME, newName);
        cv.put(COL_ITEM_QUANTITY, newQuantity);
        int rows = db.update(
                TABLE_ITEMS,
                cv,
                COL_ITEM_ID + "=?",
                new String[]{String.valueOf(id)}
        );
        db.close();
        return rows;
    }

    /** Delete an item by ID. Returns number of rows deleted. */
    public int deleteItem(long id) {
        SQLiteDatabase db = getWritableDatabase();
        int rows = db.delete(
                TABLE_ITEMS,
                COL_ITEM_ID + "=?",
                new String[]{String.valueOf(id)}
        );
        db.close();
        return rows;
    }
}
