package CS360.ProjectTwoInventoryApp;

public class Item {
    private long   id;          // Unique identifier for the item
    private String name;        // Name of the item
    private int    quantity;    // Quantity of the item

    // Constructor to initialize an Item object with id, name, and quantity
    public Item(long id, String name, int quantity) {
        this.id       = id;
        this.name     = name;
        this.quantity = quantity;
    }

    // Getters
    public long   getId()       { return id; }
    public String getName()     { return name; }
    public int    getQuantity() { return quantity; }
}