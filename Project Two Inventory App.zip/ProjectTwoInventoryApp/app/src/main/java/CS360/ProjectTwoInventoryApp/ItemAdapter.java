package CS360.ProjectTwoInventoryApp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.ItemViewHolder> {

    private List<Item> items;
    private OnItemInteraction interactionListener;

    // Constructor to initialize the adapter with the list of items and the listener
    public ItemAdapter(List<Item> items, OnItemInteraction interactionListener) {
        this.items = items;
        this.interactionListener = interactionListener;
    }

    // Creates a new view holder when RecyclerView needs it
    @NonNull
    @Override
    public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_layout, parent, false);
        return new ItemViewHolder(view);
    }

    // Binds data to the views in the ViewHolder
    @Override
    public void onBindViewHolder(@NonNull ItemViewHolder holder, int position) {
        Item item = items.get(position);
        holder.bind(item);
    }

    // Returns the total number of items in the list
    @Override
    public int getItemCount() {
        return items.size();
    }

    // ViewHolder class
    public class ItemViewHolder extends RecyclerView.ViewHolder {
        private TextView itemName, itemQuantity, itemId;

        // Constructor: Initialize the views in the ViewHolder
        public ItemViewHolder(View itemView) {
            super(itemView);
            itemName = itemView.findViewById(R.id.item_name);
            itemQuantity = itemView.findViewById(R.id.item_quantity);
            itemId = itemView.findViewById(R.id.item_id);

            // Handle click and long-click events on the item
            itemView.setOnClickListener(v -> interactionListener.onItemClick(items.get(getAdapterPosition())));
            itemView.setOnLongClickListener(v -> {
                interactionListener.onItemLongClick(items.get(getAdapterPosition()));
                return true;
            });
        }

        // Binds the item data to the views in the ViewHolder
        public void bind(Item item) {
            itemName.setText(item.getName());
            itemQuantity.setText(String.valueOf(item.getQuantity()));
            itemId.setText(String.valueOf(item.getId()));
        }
    }

    // Updates the list of items and refreshes the RecyclerView
    public void updateList(List<Item> newItems) {
        this.items = newItems;
        notifyDataSetChanged();
    }

    // Interface for item interactions (click and long-click)
    public interface OnItemInteraction {
        void onItemClick(Item item);
        void onItemLongClick(Item item);
    }
}
