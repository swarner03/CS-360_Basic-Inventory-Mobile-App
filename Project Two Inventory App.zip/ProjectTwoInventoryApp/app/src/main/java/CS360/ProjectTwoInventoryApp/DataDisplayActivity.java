package CS360.ProjectTwoInventoryApp;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.InputType;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class DataDisplayActivity extends AppCompatActivity {

    private DatabaseHelper db;
    private List<Item> items;
    private RecyclerView recyclerView;
    private ItemAdapter adapter;

    // Request code for SMS permission
    private static final int REQUEST_SMS_PERMISSION = 1001;

    // Flag to check if SMS permission is granted
    private boolean canSendSMS = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_display);

        db = new DatabaseHelper(this);
        recyclerView = findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        reloadItems();

        findViewById(R.id.fab_add_item).setOnClickListener(v -> showAddDialog());

        checkSMSPermission();
    }

    // Method to reload and display items
    private void reloadItems() {
        List<Item> fresh = db.getAllItemsOrderedById();  // order by ID ASC
        if (items == null) {
            items = fresh;
            adapter = new ItemAdapter(items, interactionListener());
            recyclerView.setAdapter(adapter);
        } else {
            items.clear();
            items.addAll(fresh);
            adapter.notifyDataSetChanged();
        }
    }

    // Method to handle item interactions (click and long click)
    private ItemAdapter.OnItemInteraction interactionListener() {
        return new ItemAdapter.OnItemInteraction() {
            @Override
            public void onItemClick(Item item) {
                showEditDialog(item);
            }

            @Override
            public void onItemLongClick(Item item) {
                showDeleteDialog(item);
            }
        };
    }

    // Show dialog to add a new item
    private void showAddDialog() {
        EditText etName = new EditText(this);
        etName.setHint("Item Name");

        new AlertDialog.Builder(this)
                .setTitle("Add Item")
                .setView(etName)
                .setPositiveButton("Next", (dialog, which) -> {
                    String name = etName.getText().toString().trim();
                    if (name.isEmpty()) {
                        Toast.makeText(this, "Name is required", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    EditText etQuantity = new EditText(this);
                    etQuantity.setHint("Quantity");
                    etQuantity.setInputType(InputType.TYPE_CLASS_NUMBER);

                    new AlertDialog.Builder(this)
                            .setTitle("Quantity for " + name)
                            .setView(etQuantity)
                            .setPositiveButton("Save", (d2, w2) -> {
                                String s = etQuantity.getText().toString().trim();
                                int qty;
                                try {
                                    qty = Integer.parseInt(s);
                                } catch (NumberFormatException e) {
                                    Toast.makeText(this, "Invalid quantity", Toast.LENGTH_SHORT).show();
                                    return;
                                }
                                db.addItem(name, qty);
                                reloadItems();

                                if (canSendSMS && qty < 5) {
                                    sendLowInventoryAlert(name, qty);
                                }
                            })
                            .setNegativeButton("Cancel", null)
                            .show();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // Show dialog to edit an item
    private void showEditDialog(Item item) {
        EditText etName = new EditText(this);
        etName.setHint("Item Name");
        etName.setText(item.getName());

        EditText etQuantity = new EditText(this);
        etQuantity.setHint("Quantity");
        etQuantity.setInputType(InputType.TYPE_CLASS_NUMBER);
        etQuantity.setText(String.valueOf(item.getQuantity()));

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Edit Item")
                .setView(etName)
                .setPositiveButton("Next", (dialog, which) -> {
                    String newName = etName.getText().toString().trim();
                    if (newName.isEmpty()) {
                        Toast.makeText(this, "Name is required", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    new AlertDialog.Builder(this)
                            .setTitle("Edit Quantity for " + newName)
                            .setView(etQuantity)
                            .setPositiveButton("Save", (d2, w2) -> {
                                String s = etQuantity.getText().toString().trim();
                                int qty;
                                try {
                                    qty = Integer.parseInt(s);
                                } catch (NumberFormatException e) {
                                    Toast.makeText(this, "Invalid quantity", Toast.LENGTH_SHORT).show();
                                    return;
                                }
                                db.updateItem(item.getId(), newName, qty);
                                reloadItems();

                                if (canSendSMS && qty < 5) {
                                    sendLowInventoryAlert(newName, qty);
                                }
                            })
                            .setNegativeButton("Cancel", null)
                            .show();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // Show dialog to delete an item
    private void showDeleteDialog(Item item) {
        new AlertDialog.Builder(this)
                .setTitle("Delete Item")
                .setMessage("Are you sure you want to delete \"" + item.getName() + "\"?")
                .setPositiveButton("Delete", (dialog, which) -> {
                    db.deleteItem(item.getId());
                    reloadItems();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // Check if the app has permission to send SMS
    private void checkSMSPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS},
                    REQUEST_SMS_PERMISSION);
        } else {
            canSendSMS = true;
        }
    }

    // Send an SMS when inventory is low
    private void sendLowInventoryAlert(String itemName, int quantity) {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            String message = "Alert: Low inventory for " + itemName + " (Qty: " + quantity + ")";
            smsManager.sendTextMessage("5554", null, message, null, null);
            Toast.makeText(this, "Low inventory SMS sent!", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Failed to send SMS", Toast.LENGTH_SHORT).show();
        }
    }

    // Handle permission result for sending SMS
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        if (requestCode == REQUEST_SMS_PERMISSION) {
            canSendSMS = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }
}
